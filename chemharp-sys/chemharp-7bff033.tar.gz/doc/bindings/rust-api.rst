.. _rust-api:

Rust interface
==============

The `Rust`_ interface to Chemharp wrap around the C interface providing a Rusty API.
All the functionalities are in the ``chemharp`` crate, which is not yet disponible on
the `crates.io`_ index.

The documentation for the Rust binding can be genrated by rustdoc.

.. _Rust: http://rust-lang.org/
.. _crates.io: http://crates.io
