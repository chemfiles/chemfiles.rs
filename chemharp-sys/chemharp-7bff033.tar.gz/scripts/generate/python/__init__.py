# -* coding: utf-8 -*

"""Generate FFI for Python ctypes module"""

from .ffi import write_ffi
