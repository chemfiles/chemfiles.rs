# Conda recipe for Chemharp

This is a [conda](http://conda.pydata.org/) recipe for packaging Chemharp for Python.
