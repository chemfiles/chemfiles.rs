Logging capacities
==================

.. doxygenclass:: harp::Logger
    :members:
