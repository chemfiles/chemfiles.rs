Atoms and atomic informations
=============================

.. doxygenclass:: harp::Atom
    :members:
