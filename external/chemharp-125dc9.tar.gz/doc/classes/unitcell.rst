Unit Cell
=========

.. doxygenclass:: harp::UnitCell
    :members:

.. doxygenenum:: harp::UnitCell::CellType
