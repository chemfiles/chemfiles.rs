Trajectory
==========

.. doxygenclass:: harp::Trajectory
    :members:
