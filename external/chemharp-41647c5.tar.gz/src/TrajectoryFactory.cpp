/*
* Chemharp, an efficient IO library for chemistry file formats
* Copyright (C) 2015 Guillaume Fraux
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0/
*/

#include "chemharp/TrajectoryFactory.hpp"


#include "chemharp/formats/XYZ.hpp"
#include "chemharp/formats/NCFormat.hpp"
#include "chemharp/formats/Molfile.hpp"

#include "chemharp/files/NCFile.hpp"
using namespace harp;

typedef FORMATS_LIST formats_list;

template <typename T>
inline void register_all_formats(trajectory_map_t& extensions, trajectory_map_t& formats, FormatList<T>) {
    auto creator = trajectory_builder_t{new_format<T>, new_file<typename T::file_t>};

    auto ext = std::string(T::extension());
    if (ext != std::string("")){
        if (extensions.find(ext) != extensions.end()) {
            throw FormatError("The extension \"" + ext + "\" is already associated with a format.");
        }
        extensions.emplace(T::extension(), creator);
    }

    auto name = std::string(T::name());
    if (name != std::string("")){
        if (formats.find(name) != formats.end()) {
            throw FormatError("The name \"" + name + "\" is already associated with a format.");
        }
        formats.emplace(name, creator);
    }
}

template <typename T, typename S, typename ...Types>
inline void register_all_formats(trajectory_map_t& extensions, trajectory_map_t& formats, FormatList<T, S, Types...>) {
    register_all_formats(extensions, formats, FormatList<T>());
    register_all_formats(extensions, formats, FormatList<S, Types...>());
}

TrajectoryFactory::TrajectoryFactory() {
    register_all_formats(extensions, names, formats_list());
}

TrajectoryFactory& TrajectoryFactory::get() {
    static TrajectoryFactory instance;
    return instance;
}

trajectory_builder_t TrajectoryFactory::format(const string& name){
    if (names.find(name) == names.end()) {
        throw FormatError("Can not find the format \"" + name + "\".");
    }
    return names[name];
}

trajectory_builder_t TrajectoryFactory::by_extension(const string& ext){
    if (extensions.find(ext) == extensions.end()) {
        throw FormatError("Can not find a format associated with the \"" + ext + "\" extension.");
    }
    return extensions[ext];
}

void TrajectoryFactory::register_format(const string& name, trajectory_builder_t tb){
    if (names.find(name) != names.end()) {
        throw FormatError("The name \"" + name + "\" is already associated with a format.");
    }
    names.emplace(name, tb);
}

void TrajectoryFactory::register_extension(const string& ext, trajectory_builder_t tb){
    if (extensions.find(ext) != extensions.end()) {
        throw FormatError("The extension \"" + ext + "\" is already associated with a format.");
    }
    extensions.emplace(ext, tb);
}
