Frames
======

.. doxygenclass:: harp::Frame
    :members:
