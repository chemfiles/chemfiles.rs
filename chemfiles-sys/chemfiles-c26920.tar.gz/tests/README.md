# Unit tests for the chemfiles library

The majority of theses tests needs some data file which you will need to get. If
you got the code with git, please use:

```bash
git submodule update --init
```

If you download the code as an archive from a release, please download the corresponding
archive from [the test repository](https://github.com/chemfiles/tests-data), and
unpack the archive into the `data` folder.
