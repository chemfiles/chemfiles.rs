#define CATCH_CONFIG_MAIN
#include "catch.hpp"

/*
 * Catch main file for faster compilation. This file is the only one defining the
 * main function.
 */
