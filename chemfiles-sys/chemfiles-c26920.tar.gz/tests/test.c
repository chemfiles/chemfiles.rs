/*
 * C dynamic library for testing the Dynlib class
 */

int foo(int a){
    return 3*a + 4;
}

double bar(){
    return 42;
}
