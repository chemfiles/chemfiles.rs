Unit Cell
=========

.. doxygenclass:: chemfiles::UnitCell
    :members:

.. doxygenenum:: chemfiles::UnitCell::CellType
