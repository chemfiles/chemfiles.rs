Trajectory
==========

.. doxygenclass:: chemfiles::Trajectory
    :members:
