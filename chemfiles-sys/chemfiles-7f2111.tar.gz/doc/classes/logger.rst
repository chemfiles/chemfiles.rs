Logging capacities
==================

.. doxygenclass:: chemfiles::Logger
    :members:
