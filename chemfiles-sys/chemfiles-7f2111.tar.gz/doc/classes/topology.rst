Topology
========

.. doxygenclass:: chemfiles::Topology
    :members:
