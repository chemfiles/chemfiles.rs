Atoms and atomic informations
=============================

.. doxygenclass:: chemfiles::Atom
    :members:
