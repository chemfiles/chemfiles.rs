Frames
======

.. doxygenclass:: chemfiles::Frame
    :members:
